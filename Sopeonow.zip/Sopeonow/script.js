// Wait for the DOM to be ready
document.addEventListener("DOMContentLoaded", function () {
    // Get references to the cards
    const wardCard = document.querySelector(".card-ward");
    const roomCard = document.querySelector(".card-room");
    const bedCard = document.getElementById("bedCard"); // Updated to use getElementById
    const paymentCard = document.querySelector(".card-payment");
  
    // Feature 2: Click on ward should alert the ward name as 'Ward 2A'
    wardCard.addEventListener("click", function () {
        alert("Ward 2A");
    });
  
    // Feature 3: Double click on Room should console.log the Room name as 'Premier Single'
    roomCard.addEventListener("dblclick", function () {
        console.log("Premier Single");
    });
  
    // Feature 4: Change the background color of Bed ID card once clicked
    bedCard.addEventListener("click", function () {
        bedCard.style.backgroundColor = "#808080";
         // Change the background color to gray (#808080)
    });
  
    // Feature 5: Clicking on payment should alert the message 'Insurance'
    paymentCard.addEventListener("click", function () {
        alert("Insurance");
    });
});
